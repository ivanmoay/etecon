@props(['link','icon','navText'])
<li class="nav-item">
    <a class="nav-link text-white " href="{{$link}}">
    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
        <i class="material-icons opacity-10">{{$icon}}</i>
    </div>
    <span class="nav-link-text ms-1">{{$navText}}</span>
    </a>
</li>